<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.4.18
    </div>
    <strong>Copyright &copy; 2023-2024 <a href="XX">POSHAN</a>.</strong> All rights
    reserved.
</footer>