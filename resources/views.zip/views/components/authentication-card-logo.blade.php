<a href="{{ url('/') }}">
    <img src="{{ asset('img/logo.png') }}" alt="Logo" style="width: 200px; height: auto;">
</a>
